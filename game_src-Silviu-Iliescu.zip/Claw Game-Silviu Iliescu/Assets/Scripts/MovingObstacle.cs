﻿using UnityEngine;
using System.Collections;

public class MovingObstacle : MonoBehaviour {
    private float x=0, z=0;
    private Rigidbody moveable;
    private Vector3 dest,dir;
    private bool pick = false;
    
    // Update is called once per frame

    void Start() {
        moveable = GetComponent<Rigidbody>();
        if (gameObject.transform.position.z == 9.2f){
            z = 18.2f;
        }
        if (gameObject.transform.position.x == 9.1f)
        {
            x = 18.1f;
        }

    }
    void Update () {
        if (x < 0 || z<0) {
            dest = new Vector3(transform.position.x+x,transform.position.y,transform.position.z+z);
            dir = (dest-transform.position).normalized;
            moveable.MovePosition(transform.position+dir*15*Time.deltaTime);
        }
        if (x > 0 || z > 0)
        {
            dest = new Vector3(transform.position.x - x, transform.position.y, transform.position.z -z);
            dir = (transform.position-dest).normalized;
            moveable.MovePosition(transform.position + dir * 15 * Time.deltaTime);
        }
        if (transform.position.z >= 9.2 && pick==false) {
            z = -18.2f;
        }
       
        if (transform.position.z <=-9.2 && pick==false)
        {
            z = 18.2f;
        }

        if (transform.position.x >= 9.1 && pick == false)
        {
            x = -18.1f;
        }

        if (transform.position.x <= -9.2 && pick == false)
        {
            x = 18.1f;
        }

        if (x == 0 && z == 0) {
            pick = true;
        }
    }
    public void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "Magnet") {
            x = 0;
            z = 0;
            gameObject.GetComponent<Rigidbody>().useGravity = true;
            gameObject.GetComponent<Rigidbody>().isKinematic = false;
        }     
    }
    }
