﻿using UnityEngine;
using System.Collections;

public class Pick : MonoBehaviour {
    public static bool hooked=false,badhook=false;
    private GameObject crane,badToy;
    void Start() {
            crane = GameObject.Find("Intersection");
    }
    public void Update() {
        crane.transform.position = GameObject.Find("Intersection").transform.position;
        if (badhook == true && crane.transform.position.y >= 15.9f) {
            badhook = false;
            hooked = false;
            ClawMovement.tries -= 2;
            Destroy(badToy);
            Destroy(GetComponent<HingeJoint>());
            Menu.points -= 5;

        }
    }
   public void OnCollisionEnter(Collision col) {
        if (col.gameObject.tag == "Toy" && hooked==false)
        {
            Debug.Log("Test");
            ClawMovement.lower = 9.5f;
            gameObject.AddComponent<HingeJoint>();
            gameObject.GetComponent<HingeJoint>().connectedAnchor = new Vector3(0,-0.5f,0);
            gameObject.GetComponent<HingeJoint>().connectedBody = col.gameObject.GetComponent<Rigidbody>();
            col.gameObject.GetComponent<Rigidbody>().drag = 1.5f;
            hooked = true;           
        }

        if (col.gameObject.tag == "Bad Toy" && hooked == false)
        {
            Debug.Log("Test");
            ClawMovement.lower = 9.5f;
            badToy = col.gameObject;
            gameObject.AddComponent<HingeJoint>();
            gameObject.GetComponent<HingeJoint>().connectedAnchor = new Vector3(0, -0.5f, 0);
            gameObject.GetComponent<HingeJoint>().connectedBody = col.gameObject.GetComponent<Rigidbody>();
            col.gameObject.GetComponent<Rigidbody>().drag = 1.5f;
            hooked = true;
            badhook = true;
        }
        }


}
