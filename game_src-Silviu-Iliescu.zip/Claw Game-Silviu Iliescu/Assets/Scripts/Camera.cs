﻿using UnityEngine;
using System.Collections;

public class Camera : MonoBehaviour
{
    private Vector3 rotate;
    private int quat = 0;
    private float x, y;
    // Use this for initialization
    void Start()
    {
        rotate = transform.rotation.eulerAngles;
    }

    // Update is called once per frame
    void Update()
    {
        x = Input.GetAxis("X Axis");
        y = Input.GetAxis("Y Axis");
        if (transform.eulerAngles.y >= 45 && transform.eulerAngles.y <= 135) {
            quat = 1;
        } else
        if (transform.eulerAngles.y < 45 || transform.eulerAngles.y > 315)
        {
            quat = 0;
        } else if (transform.eulerAngles.y > 135 && transform.eulerAngles.y <= 225) {
            quat = 2;
        }
        else if (transform.eulerAngles.y > 225 && transform.eulerAngles.y <= 315)
        {
            quat = 3;
        }

        //Update controlls based on camera rotation
        if (quat == 0)
        {
            ClawMovement.customForward = new Vector3(0, 0, 1);
            ClawMovement.customRight = new Vector3(1, 0, 0);
        }
        else if (quat == 1) {
            ClawMovement.customForward = new Vector3(1, 0, 0);
            ClawMovement.customRight = new Vector3(0, 0, -1);
        } else if (quat==2) {
            ClawMovement.customForward = new Vector3(0, 0, -1);
            ClawMovement.customRight = new Vector3(-1, 0, 0);
        }
        else if (quat == 3)
        {
            ClawMovement.customForward = new Vector3(-1, 0, 0);
            ClawMovement.customRight = new Vector3(0, 0, 1);
        }

        if (Input.GetKey("e") || x<0)
        {
            gameObject.transform.eulerAngles = new Vector3(gameObject.transform.eulerAngles.x,
                gameObject.transform.eulerAngles.y+20*Time.deltaTime,
                gameObject.transform.eulerAngles.z);
        }

        if (Input.GetKey("r") || x>0)
        {
            gameObject.transform.eulerAngles = new Vector3(gameObject.transform.eulerAngles.x,
                gameObject.transform.eulerAngles.y - 20 * Time.deltaTime,
                gameObject.transform.eulerAngles.z);
        }

        if (Input.GetKey("t") || y>0)
        {
            if (gameObject.transform.eulerAngles.x < 30 || gameObject.transform.eulerAngles.x > 334) { 
            gameObject.transform.eulerAngles = new Vector3(gameObject.transform.eulerAngles.x + 20 * Time.deltaTime,
                gameObject.transform.eulerAngles.y,
                gameObject.transform.eulerAngles.z);
        }
        }
        if (Input.GetKey("y") || y<0)
        {
            if (gameObject.transform.eulerAngles.x >= 335 || gameObject.transform.eulerAngles.x <31)
            {
                gameObject.transform.eulerAngles = new Vector3(gameObject.transform.eulerAngles.x - 20 * Time.deltaTime,
                gameObject.transform.eulerAngles.y,
                gameObject.transform.eulerAngles.z);
            }
        }

    }
}
