﻿using UnityEngine;
using System.Collections;

public class CollectToy : MonoBehaviour {
    public static bool playCollectSound=false;
    public static int goal=0;
    private AudioSource collect;
    public void Start() {
        collect = GetComponent<AudioSource>();
        goal = 0;
    }
    public void OnCollisionEnter(Collision col) {
        if (col.gameObject.tag == "Toy") {
            //big toy
            if (col.transform.localScale.x == 1.5f) {
                ClawMovement.tries += 2;
                Menu.time += 10.0f;
                Menu.points += 5;
            }
            //Small toy
            if (col.transform.localScale.x == 1) {
                ClawMovement.tries += 4;
                Menu.time += 2.00f;
                Menu.points += 10;
            }
            Destroy(col.gameObject);
            Destroy(GameObject.Find("MagnetPoint").GetComponent<HingeJoint>());            
            collect.Play();
            playCollectSound = true;
            goal += 1;
            StartCoroutine(Wait());
            
        }
    }

    public IEnumerator Wait() {
        ClawMovement.lower = 8.0f;
        yield return new WaitForSeconds(2);
        Pick.hooked = false;        
        
    }
}
