﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Menu : MonoBehaviour {
    private Text pointsText;
    private Text timerText,attemps,winLoseText;
    public static float time;
    public static int points;
    private AudioSource buttonSound;
    private bool pause=false,win=false,lose=false;
    private GameObject intro,credits,pauseMenu,buttonsMenu,winLoseMenu;


    public void ResumeButton() {
        pause = false;
    }

    public void StartButton() {
        buttonSound.Play();
        SceneManager.LoadScene(1);
    }

    public void CreditsButton() {
        buttonSound.Play();
        intro.SetActive(false);
        credits.SetActive(true);
    }

    public void ButtonsButton()
    {
        buttonSound.Play();
        intro.SetActive(false);
        buttonsMenu.SetActive(true);
    }

    public void QuitButton() {
        buttonSound.Play();
        Application.Quit();
    }

    public void BackButton() {
        buttonSound.Play();
        intro.SetActive(true);
        credits.SetActive(false);
        buttonsMenu.SetActive(false);
    }

    public void BackToMenuButton() {
        SceneManager.LoadScene(0);
    }
    public void Start() {
        if (Application.loadedLevel == 1)
        {
            pointsText = GameObject.Find("Points").GetComponent<Text>();
            timerText = GameObject.Find("Timer").GetComponent<Text>();
            attemps = GameObject.Find("Attemps").GetComponent<Text>();
            winLoseText = GameObject.Find("WinLoseText").GetComponent<Text>();

            pauseMenu = GameObject.Find("PauseMenu");
            winLoseMenu = GameObject.Find("Win/Lose");


            pauseMenu.SetActive(false);
            winLoseMenu.SetActive(false);          
            time = 60;
        }
        else {
            intro = GameObject.Find("MainMenu");
            credits = GameObject.Find("CreditsText");
            buttonsMenu = GameObject.Find("ButtonsPanel");
            credits.SetActive(false);
            buttonsMenu.SetActive(false);
            buttonSound = GetComponent<AudioSource>();
        }
    }
    public void Update()
    {
        //To avoid the NullReference
        if (Application.loadedLevel == 1)
        {
            pointsText.text = "Points: " + points;
            time -= Time.deltaTime;
            timerText.text = "Time: " + time.ToString("0");
            attemps.text = "Attemps: " + ClawMovement.tries.ToString();
            if (Input.GetButtonDown("Escape"))
            {
                pause = !pause;
            }
            if (pause == true && win==false && lose==false)
            {
                pauseMenu.SetActive(true);
                Cursor.visible = true;
                Time.timeScale = 0.0f;;
                Cursor.lockState = CursorLockMode.None;
            }
            else if(pause==false && win == false && lose == false)
            {
                pauseMenu.SetActive(false);
                Cursor.visible = false;
                Cursor.lockState = CursorLockMode.Locked;
                Time.timeScale = 1.0f;
            }
            if (CollectToy.goal == 4) {
                win = true;
            }
            if (time <= 0 || ClawMovement.tries <= 0) {
                lose = true;
            }

            if (win == true) {
                winLoseMenu.SetActive(true);
                Cursor.visible = true;
                Time.timeScale = 0.0f; ;
                Cursor.lockState = CursorLockMode.None;
                winLoseText.color = new Color(0.0f,1.0f,0.0f);
                winLoseText.text = "You Win!!!";
            }

            if (lose == true) {
                winLoseMenu.SetActive(true);
                Cursor.visible = true;
                Time.timeScale = 0.0f; ;
                Cursor.lockState = CursorLockMode.None;
                winLoseText.color = new Color(1.0f, 0.0f, 0.0f);
                winLoseText.text = "You Lose!!!";
            }

        }
    }

}
