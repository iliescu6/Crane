﻿using UnityEngine;
using System.Collections;

public class ClawMovement : MonoBehaviour {
    private Rigidbody claw;
    private bool pick = false,raise=false;
    private Vector3 initial;
    public static float lower = 8.0f;
    public static int tries;
    private float h, v;
    public static Vector3 customForward,customRight;
    private AudioSource clawSound;
    void Start() {
        tries = 5;
        claw = GetComponent<Rigidbody>();
        clawSound = GetComponent<AudioSource>();
        customForward = new Vector3(0,0,1);
        customRight = new Vector3(1, 0, 0);

    }
	// Update is called once per frame
	void Update () {
        v = Input.GetAxis("Vertical");
        h = Input.GetAxis("Horizontal");

        if (v<0) {
            claw.MovePosition(transform.position+customForward*Time.deltaTime*10);
        }
        if (v > 0)
        {
            claw.MovePosition(transform.position + customForward*-1* Time.deltaTime * 10);
        }
        if (h<0) {
            claw.MovePosition(transform.position + customRight*1* Time.deltaTime * 10);
        }
        if (h>0)
        {
            claw.MovePosition(transform.position + customRight*-1 * Time.deltaTime * 10);
        }

        if (Input.GetButtonDown("Lower") && pick==false) {
            pick = true;
            clawSound.Play();
        }
        if (pick == true)
        {
            Vector3 destination = new Vector3(transform.position.x, transform.position.y - 7, transform.position.z);
            Vector3 direction = (destination - transform.position).normalized;
            claw.MovePosition(transform.position + direction * 10 * Time.deltaTime);
            if (transform.position.y <= lower)
            {
                raise = true;
                pick = false;
            }
        }
           if (raise == true) {
                Vector3 top = new Vector3(transform.position.x, 16, transform.position.z);
                Vector3 bDirection = (top-transform.position).normalized;
                claw.MovePosition(transform.position + bDirection * 10 * Time.deltaTime);
                if (transform.position.y >=16)
                {
                claw.position = new Vector3(transform.position.x,16,transform.position.z);
                
                    raise = false;
            }
            if (raise == false && Pick.hooked == false) {
                tries -= 1;
                
            }
            }

        }
    }

